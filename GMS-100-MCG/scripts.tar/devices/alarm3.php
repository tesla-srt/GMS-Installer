#!/usr/bin/php
<?php
//error_reporting(E_ALL);
//Surge ALERT
include "/data/custom/scripts/classes/Logger.php";
Logger::LogEvent(Logger::ALARM3);
$clean_file = '/tmp/surge';    // Define the folder to clean (keep trailing slashes)
$value = trim(file_get_contents("/var/rmsdata/alarm3"));


$dbh = new PDO('sqlite:/etc/rms100.db');

$result = $dbh->query("SELECT * FROM io WHERE id='3' AND type='alarm';");

$surgeAlertFlap = "0";
foreach ($result as $row) {
    $surgeAlertFlap = $row['hi_flap'];
}

$result = $dbh->query("SELECT * FROM custom");
foreach ($result as $row) {
    $surgeAlertState = $row['surgeAlertState'];
}

$surgeAlertState = (bool)$surgeAlertState;
$time_now = time();


if ($surgeAlertState === TRUE) {
    if (!file_exists($clean_file) && $value == 1) {
        $myfile = fopen($clean_file, "w");
        fclose($myfile);
        exec("/bin/rmsalert 6.");
    } else if (file_exists($clean_file)) {
        $FileCreationTime = filectime($clean_file);
        $FileAge = $time_now - $FileCreationTime;
        if ($FileAge >= $surgeAlertFlap) {
            if ($value == 1) {
                exec("/bin/rmsalert 6.");
            } else {
                unlink($clean_file);
            }
        }
        if ($value == 0) {
            unlink($clean_file);
        }
    }

}
?>