<?php
//include_once "/data/custom/html/mattLib/Utils.php";
$ip_address = $_SERVER['SERVER_ADDR'];
$mac = file_get_contents("/var/macaddress");
$mac = str_replace("\n", '', $mac); // remove new lines
$ip_address = $_SERVER['SERVER_ADDR'];
$alertSubjects[0] = "FAULT - Tamper Event"; //4
$alertSubjects[1] = "OPEN - Door Contact Event"; //5
$alertSubjects[2] = "FAULT - Surge Protection Event"; //6
$alertSubjects[3] = "FAULT - PoE Switch Event"; //7
$alertSubjects[4] = "POWER OUT - System Event"; //8
$alertSubjects[5] = "LOW POWER - Battery Bank Event"; //9
$alertSubjects[6] = "POWER OUT - PoE Switch Event"; //10
$alertSubjects[7] = "POWER RESTORED - System Event"; //11
$alertSubjects[8] = "Low Temperature Event"; //12
$alertSubjects[9] = "High Temperature Event"; //13
$alertSubjects[10] = "Test Alert"; //14
$len = count($alertSubjects);
$offset = 4;

    $result  = $dbh->query("SELECT syslocation FROM snmp_config;");
    foreach($result as $row)
    {
        $location = $row['syslocation'];
    }

for ($i = 0; $i < $len; $i++)
{
    $alertSubjects[$i] = $hostName." @ ".$location." - ".$alertSubjects[$i];
    $bodyString = "System Event From ".$hostName."@" . $location. "\nMAC: ".$mac."\nIP: ".$ip_address;
    $query = sprintf("UPDATE alerts SET desc='%s', v2='%s', v4='%s' WHERE id='%d';", $alertSubjects[$i], $alertSubjects[$i], $bodyString, ($i+$offset));
    $dbh->exec($query);
}