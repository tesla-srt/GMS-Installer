#!/usr/bin/php
<?php
    //error_reporting(E_ALL);
    include_once "/data/custom/html/mattLib/Utils.php";
    setPcState(ON_STATE);
    setHasPcOnBeenTriggered(OFF_STATE);
?>