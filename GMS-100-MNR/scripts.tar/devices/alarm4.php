#!/usr/bin/php
<?php
//error_reporting(E_ALL);
//PoE Switch
include "/data/custom/scripts/classes/Logger.php";
Logger::LogEvent(Logger::ALARM4);
$clean_file = '/tmp/poe';    // Define the folder to clean (keep trailing slashes)
$value = trim(file_get_contents("/var/rmsdata/alarm4"));

$dbh = new PDO('sqlite:/etc/rms100.db');

$result = $dbh->query("SELECT * FROM io WHERE id='4' AND type='alarm';");

$switchAlertFlap = "0";
foreach ($result as $row) {
    $switchAlertFlap = $row['lo_flap'];
}

$result = $dbh->query("SELECT * FROM custom");
foreach ($result as $row) {
    $switchAlertState = $row['switchAlertState'];
}

$switchAlertState = (bool)$switchAlertState;
$time_now = time();
if ($switchAlertState === TRUE) {
    if (!file_exists($clean_file) && $value == 0) {
        $myfile = fopen($clean_file, "w");
        fclose($myfile);
        exec("/bin/rmsalert 7.");
    } else if (file_exists($clean_file)) {
        $FileCreationTime = filectime($clean_file);
        $FileAge = $time_now - $FileCreationTime;
        if ($FileAge >= $switchAlertFlap) {
            if ($value == 0) {
                exec("/bin/rmsalert 7.");
            } else {
                unlink($clean_file);
            }
        }
        if ($value == 1) {
            unlink($clean_file);
        }
    }

}

?>