#!/usr/bin/php
<?php
//Door Contact Alarm
//error_reporting(E_ALL);
include "/data/custom/scripts/classes/Logger.php";
Logger::LogEvent(Logger::ALARM2);
$clean_file = '/tmp/door';    // Define the folder to clean (keep trailing slashes)
$value = trim(file_get_contents("/var/rmsdata/alarm2"));

$dbh = new PDO('sqlite:/etc/rms100.db');

$result = $dbh->query("SELECT * FROM io WHERE id='2' AND type='alarm';");

$doorAlertFlap = "0";
foreach ($result as $row) {
    $doorAlertFlap = $row['hi_flap'];
}

$result = $dbh->query("SELECT * FROM custom");
foreach ($result as $row) {
    $doorAlertState = $row['doorAlertState'];
}

$doorAlertState = (bool)$doorAlertState;
$time_now = time();

if($doorAlertState === TRUE) {
    if (!file_exists($clean_file) && $value == 1) {
        $myfile = fopen($clean_file, "w");
        fclose($myfile);
        exec("/bin/rmsalert 5.");
    } else if (file_exists($clean_file)) {
        $FileCreationTime = filectime($clean_file);
        $FileAge = $time_now - $FileCreationTime;
        if($FileAge >= $doorAlertFlap) {
            if ($value == 1) {
                exec("/bin/rmsalert 5.");
            } else {
                unlink($clean_file);
            }
        }
        if ($value == 0) {
            unlink($clean_file);
        }
    }

}
?>