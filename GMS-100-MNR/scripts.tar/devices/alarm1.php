#!/usr/bin/php
<?php
//Tamper Alert
include "/data/custom/scripts/classes/Logger.php";
//include "/data/custom/html/mattLib/DatabaseHandler.php";
Logger::LogEvent(Logger::ALARM1);

$tamperAlertState = '';
$clean_file   = '/tmp/tamper';	// Define the folder to clean (keep trailing slashes)
$expire_time    = 120; 						// Here you can define after how many minutes the files should get deleted
$myfile = '';
$value = trim(file_get_contents("/var/rmsdata/alarm1"));
$dbh = new PDO('sqlite:/etc/rms100.db');

$result = $dbh->query("SELECT * FROM io WHERE id='1' AND type='alarm';");

$tamperAlertFlap = "0";
foreach($result as $row)
{
    $tamperAlertFlap = $row['hi_flap'];
}

$result = $dbh->query("SELECT * FROM custom");
foreach($result as $row)
{
    $tamperAlertState = $row['tamperAlertState'];
}


/*if (!file_exists($clean_file)) {
    $myfile = fopen($clean_file, "w");
    fclose($myfile);
} else {
    $FileCreationTime = filectime($myFile);
    $FileAge = $time_now - $FileCreationTime;
    if ($FileAge > $expire_time) {
        //exec("/bin/rmsalert 4.");
        unlink($clean_file);
    }
}*/
$time_now = time();

if($tamperAlertState === TRUE) {
    if (!file_exists($clean_file) && $value == 1) {
        $myfile = fopen($clean_file, "w");
        fclose($myfile);
        exec("/bin/rmsalert 4.");
    } else if (file_exists($clean_file)) {
        $FileCreationTime = filectime($clean_file);
        $FileAge = $time_now - $FileCreationTime;
        if($FileAge >= $tamperAlertFlap) {
            if ($value == 1) {
                exec("/bin/rmsalert 4.");
            } else {
                unlink($clean_file);
            }
        }
    }
}


         /**


         IF tmp/tamper.a1 does not exist
            create tamper.a1
        ELSE
        if tamper.a1 is older than 30sec
            rmsAlert()
            delete tamper.a1

          *
          *
          *
          * if alert on
          *      if file not exist && value = 1
          *         createfile
          *         sendalert
          *     else if value =1 && fileage > flap
          *         send alert
          *     else
          *         unlink file

         */
    
?>