#!/bin/sh
rmsscript 3.3.